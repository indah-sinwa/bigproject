package page_object;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.baseclass;

public class object_class extends baseclass {

	public object_class(WebDriver webDriver) {
		super(webDriver);
		PageFactory.initElements(webDriver, this);
	}

	// PIM - Add User
	@FindBy(id = "menu_pim_viewPimModule")
	private WebElement btnPimModule;
	public void btnPimModule() {
		btnPimModule.click();
	}

	@FindBy(id = "btnAdd")
	private WebElement btnAddNewUser;

	public void btnAddNewUser() {
		btnAddNewUser.click();
	}

	@FindBy(id = "firstName")
	private WebElement txtInputFirstName;

	public void txtInputFirstName(String firstNameUser) {
		txtInputFirstName.sendKeys(firstNameUser);
	}

	@FindBy(id = "lastName")
	private WebElement txtInputLastName;

	public void txtInputLastName(String lastNameUser) {
		txtInputLastName.sendKeys(lastNameUser);
	}

	@FindBy(id = "employeeId")
	private WebElement txtInputEmpId;

	public void txtInputEmpId(String employeeIdUser) {
		txtInputEmpId.clear();
		txtInputEmpId.sendKeys(employeeIdUser);
	}

	@FindBy(id = "btnSave")
	private WebElement btnSaveNewUser;

	public void btnSaveNewUser() {
		btnSaveNewUser.click();
	}

	@FindBy(id = "employee-details")
	private WebElement viewEmpDetails;

	public boolean viewEmpDetails() {
		return viewEmpDetails.isDisplayed();
	}

	// PIM - Edit User
	@FindBy(id = "btnSave")
	private WebElement btnEditUser;

	public void btnEditUser() {
		btnEditUser.click();
	}

	@FindBy(id = "personal_txtEmpMiddleName")
	private WebElement txtInputMiddleName;

	public void txtInputMiddleName(String personal_txtEmpMiddleNameUser) {
		txtInputMiddleName.sendKeys(personal_txtEmpMiddleNameUser);
	}

	@FindBy(id = "btnSave")
	private WebElement btnSaveUpdate;

	public void btnSaveUpdate() {
		btnSaveUpdate.click();
	}

	// PIM - Search Employee User
	@FindBy(id = "menu_pim_viewEmployeeList")
	private WebElement viewEmpList;

	public void viewEmpList() {
		viewEmpList.click();
	}
	
	@FindBy(id = "empsearch_id")
	private WebElement txtInputCode;
	public void txtInputCode(String inputKodeEmp) {
		txtInputCode.sendKeys(inputKodeEmp);
	}

	public void EmployeeName() throws InterruptedException {
		Select EmployeeName = new Select(webDriver.findElement(By.id("resultTable")));
		EmployeeName.selectByVisibleText("Assistent");
		Thread.sleep(2000);
	}

	@FindBy(id = "searchBtn")
	private WebElement btnSearchUser;

	public void btnSearchUser() {
		btnSearchUser.click();
	}

	@FindBy(xpath = "//td[.='Assistent']")
	private WebElement resultName;

	public String getResultNameAct() {
		return resultName.getText();
	}

	// PIM - Delete Employee User
	@FindBy(id = "ohrmList_chkSelectRecord_80")
	private WebElement DeleteEmp;

	public void DeleteEmp() {
		DeleteEmp.click();
	}

	@FindBy(id = "deleteConfModal")
	private WebElement boxConfirmDeleteEmp;

	public void boxConfirmDeleteEmp() {
		boxConfirmDeleteEmp.isEnabled();
	}

	@FindBy(id = "dialogDeleteBtn")
	private WebElement btnConfirmDeleteEmp;

	public void btnConfirmDeleteEmp() {
		btnConfirmDeleteEmp.click();
	}

	// Admin - Add new Emp
	@FindBy(id = "menu_admin_viewAdminModule")
	private WebElement btnAdminModule;

	public void btnAdminModule() {
		btnAdminModule.click();
	}

	@FindBy(id = "btnAdd")
	private WebElement btnAddUserAdmin;

	public void btnAddUserAdmin() {
		btnAddUserAdmin.click();
	}
	
	@FindBy(id = "systemUser_userName")
	private WebElement User_Name;

	public void User_Name(String Akuh) {
		User_Name.clear();
		User_Name.sendKeys(Akuh);
	}

	public void UserRple() throws InterruptedException {
		Select UserRole = new Select(webDriver.findElement(By.id("systemUser_userType")));
		UserRole.selectByVisibleText("Admin");
		Thread.sleep(1000);
	}

	public void EmployName() throws InterruptedException {
		Select EmployName = new Select(webDriver.findElement(By.id("systemUser_employeeName_empName")));
		EmployName.selectByVisibleText("John John Doe");
		Thread.sleep(1000);
	
	}

	public void EmployStatus() throws InterruptedException {
		Select EmployStatus = new Select(webDriver.findElement(By.id("systemUser_status")));
		EmployStatus.selectByIndex(0);
		Thread.sleep(1000);
	}

	@FindBy(id = "systemUser_password")
	private WebElement txtInputPassUser;

	public void txtInputPassUser(String txtuserpass) {
		txtInputPassUser.sendKeys(txtuserpass);
	}

	@FindBy(id = "systemUser_confirmPassword")
	private WebElement txtInputConfPass;

	public void txtInputConfPass(String txtuserconfpass) {
		txtInputConfPass.sendKeys(txtuserconfpass);
	}

	@FindBy(id = "btnSave")
	private WebElement btnSaveEmpUser;

	public void btnSaveEmpUser() {
		btnSaveEmpUser.click();
	}

	// Admin - Search User
	@FindBy(id = "searchSystemUser_userName")
	private WebElement txtUserName;

	public void txtUserName(String KetxtUserNameyword) {
		txtUserName.sendKeys(KetxtUserNameyword);
	}

	@FindBy(id = "searchBtn")
	private WebElement btnSearch;

	public void btnSearch() {
		btnSearch.click();
	}

	@FindBy(css = "td:nth-of-type(1) > a")
	private WebElement resultUserName;

	public String actUserName() {
		return resultUserName.getText();
	}

	public String expUserName() {
		return "Billy Joe Armstrong";
	}

	// Admin - Delete User
	@FindBy(id = "ohrmList_chkSelectRecord_66")
	private WebElement checkBoxDeleteAdmin;

	public void checkBoxDeleteAdmin() {
		checkBoxDeleteAdmin.click();
	}

	@FindBy(id = "deleteConfModal")
	private WebElement boxConfirm;

	public void boxConfirm() {
		boxConfirm.isDisplayed();
	}

	@FindBy(id = "dialogDeleteBtn")
	private WebElement btnDialogDelete;

	public void btnDialogDelete() {
		btnDialogDelete.click();
	}

	// Leave - Assign Leave
	@FindBy(id = "menu_leave_viewLeaveModule")
	private WebElement btnviewLeave;

	public void btnviewLeave() {
		btnviewLeave.click();
	}

	@FindBy(id = "menu_leave_assignLeave")
	private WebElement btnAssignLeave;

	public void btnAssignLeave() {
		btnAssignLeave.click();
	}

	@FindBy(xpath = "//input[@id='assignleave_txtEmployee_empName']")
	private WebElement leaveAssignName;

	public void leaveAssignName(String employeeNameToLeave) {
		leaveAssignName.clear();
		leaveAssignName.sendKeys(employeeNameToLeave);
	}

	public void leaveType() {
		Select leaveType = new Select(webDriver.findElement(By.id("assignleave_txtLeaveType")));
		leaveType.selectByVisibleText("Sick");
	}

	@FindBy(id = "assignleave_txtFromDate")
	private WebElement leaveAssignFromDate;

	public void leaveAssignFromDate(String leaveFromDate) {
		leaveAssignFromDate.clear();
		leaveAssignFromDate.sendKeys(leaveFromDate);
		leaveAssignFromDate.sendKeys(Keys.ENTER);
	}

	@FindBy(id = "assignleave_txtToDate")
	private WebElement leaveAssignToDate;

	public void leaveAssignToDate(String leaveToDate) {
		leaveAssignToDate.clear();
		leaveAssignToDate.sendKeys(leaveToDate);
		leaveAssignToDate.sendKeys(Keys.ENTER);
	}

	public void durationDays() {
		new WebDriverWait(webDriver, 20)
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@id='frmLeaveApply']//li[8]")));
		new WebDriverWait(webDriver, 20).until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//select[@id='assignleave_firstDuration_duration']")));
		Select durationDays = new Select(webDriver.findElement(By.id("assignleave_duration_duration")));
		durationDays.selectByVisibleText("Half Day");
	}

	public void durationTimeFrom() {
		Select durationTimeFrom = new Select(webDriver.findElement(By.id("assignleave_duration_ampm")));
		durationTimeFrom.selectByValue("AM");

	}

	@FindBy(id = "assignBtn")
	private WebElement btnAssign;

	public void btnAssign() {
		btnAssign.click();
	}

	@FindBy(id = "leaveBalanceConfirm")
	private WebElement boxConfirmLeave;

	public void boxConfirmLeave() {
		boxConfirmLeave.isDisplayed();
	}

	@FindBy(id = "confirmOkButton")
	private WebElement btnConfirmOk;

	public void btnConfirmOk() {
		btnConfirmOk.click();
	}

	// Leave - Search Leave List
	@FindBy(id = "menu_leave_viewLeaveList")
	private WebElement btnLeaveList;

	public void btnLeaveList() {
		btnLeaveList.click();
	}

	@FindBy(id = "leaveList_chkSearchFilter_checkboxgroup_allcheck")
	private WebElement checkAllStatus;

	public void checkAllStatus() {
		checkAllStatus.click();
	}

	@FindBy(id = "leaveList_txtEmployee_empName")
	private WebElement dropEmpLeaveName;

	public void searchNameLeave(String fullNameLeave) {
		dropEmpLeaveName.clear();
		dropEmpLeaveName.sendKeys(fullNameLeave);

	}

	@FindBy(id = "btnSearch")
	private WebElement btnSearchMyLeave;

	public void btnSearchMyLeave() {
		btnSearchMyLeave.click();
	}

	@FindBy(id = "select_leave_action_28")
	private WebElement ActionsBox;

	public void ActionsBox() {
		ActionsBox.isDisplayed();
	}

	@FindBy(linkText = "Assistent IndahQA1")
	private WebElement resultSearchName;

	public void resultSearchName() {
		resultSearchName.isDisplayed();
	}

	public String expResultLeaveName() {
		return "Assistent IndahQA1";
	}

	public String actResultLeaveName() {
		return resultSearchName.getText();
	}

	@FindBy(xpath = "//a[.='Cancelled(1.00)']")
	private WebElement statusLeave;

	public String actStatusLeave() {
		return statusLeave.getText();

	}

	public String expStatusLeave() {
		return "Cancelled(1.00)";

	}

	// Burgermenu - Logout
	@FindBy(xpath = "a[@id='welcome']")
	private WebElement WelcomeAdmin;

	public void WelcomeAdmin() {
		WelcomeAdmin.click();
	}

	@FindBy(xpath = "a{.='Logout']")
	private WebElement hrefLogout;

	public void hrefLogout() {
		hrefLogout.click();
	}

	
}
