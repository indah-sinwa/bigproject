package page_object;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilities.baseclass;

public class login_page {
	public WebDriver driver;
	public login_page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(id = "txtUsername")
	private WebElement inputUsername;

	@FindBy(id = "txtPassword")
	private WebElement inputPassword;

	@FindBy(id = "btnLogin")
	private WebElement btnLogin;

	// login sukses
	@FindBy(xpath = "//h1[.='Dashboard']")
	private WebElement dashboard;

	public boolean isLoginSuccess() {
		dashboard.isDisplayed();
		return true;
	}

	public void setUsername(String username) {
		inputUsername.sendKeys(username);
	}

	public void setPassword(String password) {
		inputPassword.sendKeys(password);
	}

	public void clickBtnLogin() {
		btnLogin.click();
	}
	
	@FindBy(id = "spanMessage")
	private WebElement ErrorMessageLogIn;
	
	public boolean isloginpage() {
		inputUsername.isDisplayed();
		inputPassword.isDisplayed();
		btnLogin.isDisplayed();
		return true;
	}

	
	public void setInvalidUsername(String invusername) {
		inputUsername.sendKeys(invusername);

	}

	public void setInvalidPassword(String invpassword) {
		inputPassword.sendKeys(invpassword);
	}

	public void clickLoginButton() {
		btnLogin.click();
	}
	
	public boolean isErrorMessageAppear() {
		ErrorMessageLogIn.isDisplayed();
		
		return true;

	}

}
