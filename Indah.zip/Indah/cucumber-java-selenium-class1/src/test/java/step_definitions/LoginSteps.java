package step_definitions;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import page_object.login_page;

public class LoginSteps {
public static WebDriver driver;
    
    public LoginSteps()
    {
    	driver = Hooks.driver;
}
    
    @Given("User already on OrangeHRM login page")
    public static void LoginPage() throws Throwable {
    	login_page Login = new login_page(driver);
    	Assert.assertTrue(Login.isloginpage());
    }
    
    @When("User input credential \\\"(.*)\\\" as username & \\\"(.*)\\\" as password")
    public static void InputCredential(String username, String password) throws Throwable {
    	login_page Login = new login_page(driver);
    	Login.setUsername(username);
    	Login.setPassword(password);
    }
    @And("User click button login")
    public static void ClickLogin() throws Throwable {
    	login_page Login = new login_page(driver);
    	Login.clickBtnLogin();
    }
    
    @Then("User should be redirect to Dashboard Admin")
    public static void AdminPage() throws Throwable {
    	login_page Login = new login_page(driver);
    	Assert.assertTrue(Login.isLoginSuccess());
    }
}