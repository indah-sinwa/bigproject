package step_definitions;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"classpath:features/"},
		glue = { "classpath:step_definitions"},
		//glue = { "step_definitions.Addition", "step_definitions.Hooks", "step_definitions.BrowserCommands"},
		plugin = {"pretty", "html:target/cucumber-html-report.html","json:target/cucumber.json"}
		)
public class RunCukesTest{
	
}