package step_definitions;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import page_object.login_page;
import page_object.object_class;

public class Admin {
	public static WebDriver driver;

	public Admin() {
		driver = Hooks.driver;
	}
	@Given("1User already login on OrangeHRM using \"(.*)\" as username &  \"(.*)\"as password")
	public void user_already_login_on_orange_hrm_using_as_username_as_password(String username, String password) throws Throwable {
		login_page Login = new login_page(driver);
		Assert.assertTrue(Login.isloginpage());
		Login.setUsername(username);
		Login.setPassword(password);
		Login.clickBtnLogin();
		Thread.sleep(3000);
	}
	
	@When("User click Admin and click delete button")
	public void goToAdminPageToAddUser() throws Throwable {
		object_class AllPage = new object_class(driver);
		AllPage.btnAdminModule();
		AllPage.checkBoxDeleteAdmin();
		Thread.sleep(2000);
		AllPage.boxConfirm();
		AllPage.btnDialogDelete();

	}

	@Then("User view employee list")
	public void ViewEmpList(String Keyword) throws Throwable {
		object_class ViewEmpLost = new object_class(driver);
		ViewEmpLost.btnAdminModule();
	}
}