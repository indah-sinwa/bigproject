package step_definitions;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import page_object.login_page;
import page_object.object_class;

public class PIM {
	public static WebDriver driver;

	public PIM() {
		driver = Hooks.driver;
    }
	
	@Given("Admin already login on OrangeHRM using \\\"(.*)\\\" as username & \\\"(.*)\\\" as password")
	public void Login(String username, String password) throws Throwable {
		login_page Login = new login_page(driver);
		Assert.assertTrue(Login.isloginpage());
		Login.setUsername(username);
		Login.setPassword(password);
		Login.clickBtnLogin();
		Thread.sleep(3000);
	}
	
	@When("Admin click PIM button & click add employee button")
	public void AddNewUser() throws Throwable {
		object_class AddNewUser = new object_class(driver);
		AddNewUser.btnPimModule();
		Thread.sleep(3000);
		AddNewUser.btnAddNewUser();
		Thread.sleep(3000);			
	}
	
	@And("Admin input \"(.*)\" as firstName & input \"(.*)\" as lastName & input \"(.*)\" as EmployeeId")
	public void InputForm (String firstNameUser, String lastNameUser, String employeeIdUser) throws Throwable {
	object_class InputForm = new object_class(driver);
	InputForm.txtInputFirstName(firstNameUser);
	InputForm.txtInputLastName(lastNameUser);
	InputForm.txtInputEmpId(employeeIdUser);
	InputForm.btnSaveNewUser();
	Thread.sleep(3000);
	}
	
	@And("Admin Edit Employee Details")
	public void EditEmp (String personal_txtEmpMiddleNameUser) throws Throwable {
		object_class EditEmp = new object_class(driver);
		Assert.assertFalse(EditEmp.viewEmpDetails());
		EditEmp.btnEditUser();
		EditEmp.txtInputMiddleName(personal_txtEmpMiddleNameUser);
		EditEmp.btnSaveUpdate();
	}
	
	@Then("Admin Success Add Employee")
	public void ViewDetails()throws Throwable {
		
	}
	
	//Search User Employee
	@Given("Admin already login on OrangeHRM using \\\"(.*)\\\" as username & \\\"(.*)\\\" as password")
	public void Login1(String username, String password) throws Throwable {
		login_page Login = new login_page(driver);
		Assert.assertTrue(Login.isloginpage());
		Login.setUsername(username);
		Login.setPassword(password);
		Login.clickBtnLogin();
		Thread.sleep(3000);
	}
	
	@When("Admin Search Employee")
	public void Search ()throws Throwable {
		object_class Search = new object_class(driver);
		Search.viewEmpList();
	}
	
	@And("Admin input \\\"(.*)\\\" as employee code")
	public void InputCode(String EmployeeName) throws Throwable {
		object_class InputCode = new object_class(driver);
		InputCode.txtInputCode(EmployeeName);
	}
	
	@Then("Admin View Search Result")
	public void Result() throws Throwable {	
	object_class Result = new object_class(driver);
		Result.EmployeeName();
	}
}
