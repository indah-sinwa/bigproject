package step_definitions;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import page_object.login_page;
import page_object.object_class;

public class Leave {
	public static WebDriver driver;
	public Leave() {
		driver = Hooks.driver;
		
	}
	
	@Given("Admin already login on OrangeHRM using \"(.*)\" as username & \"(.*)\" as password")
	public void Login(String username, String password) throws Throwable {
		login_page Login = new login_page(driver);
		Assert.assertTrue(Login.isloginpage());
		Login.setUsername(username);
		Login.setPassword(password);
		Login.clickBtnLogin();
		Thread.sleep(3000);
	}
	
	@When("Admin choose Leave Menu and Click leave button")
	public void goToAssignLeave1() throws Throwable {
	object_class Leave = new object_class(driver);
	Leave.btnLeaveList();
	Leave.checkAllStatus();	
	}

	
	@And("Admin Assign Leave and input \"(.*)\" as employeeNameToLeave and \"(.*)\" as leaveFromDate and \"(.*)\" as leaveToDate")
	public void AssignLeave (String employeeNameToLeave, String leaveFromDate, String leaveToDate) throws Throwable {
		object_class AssignLeave = new object_class(driver);
		AssignLeave.leaveAssignFromDate(leaveFromDate);
		AssignLeave.leaveAssignToDate(leaveToDate);
		AssignLeave.leaveType();
		AssignLeave.EmployeeName();
		AssignLeave.durationDays();
		AssignLeave.btnAssign();
		AssignLeave.boxConfirmLeave();
		AssignLeave.btnConfirmOk();
	}
	
	@Then("Admin successfully assign leave")
	public void successfulAssignLeave() throws Throwable {
		
	}
	
	
}
