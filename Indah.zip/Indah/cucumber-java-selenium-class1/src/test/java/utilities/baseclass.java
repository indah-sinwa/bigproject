package utilities;

import org.openqa.selenium.WebDriver;

public class baseclass {
	
		public static WebDriver webDriver;
	

		public baseclass(WebDriver webDriver) {
			baseclass.webDriver = webDriver;
		}
	}